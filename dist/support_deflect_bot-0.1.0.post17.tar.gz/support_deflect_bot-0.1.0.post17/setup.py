"""Minimal setup.py for backward compatibility.

All project configuration is now in pyproject.toml.
This file is kept for compatibility with older tools.
"""

from setuptools import setup

# All configuration now in pyproject.toml
setup()
