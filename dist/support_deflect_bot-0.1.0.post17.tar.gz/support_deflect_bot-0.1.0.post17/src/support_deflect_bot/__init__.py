"""Support Deflect Bot - Intelligent document Q&A with confidence-based refusal."""

__version__ = "0.2.0"
__author__ = "Aditya Mittal"
__email__ = "theadityamittal@gmail.com"
