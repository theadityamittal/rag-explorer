"""Core functionality for Support Deflect Bot."""
