"""Command-line interface for Support Deflect Bot."""

from .main import cli

__all__ = ["cli"]
